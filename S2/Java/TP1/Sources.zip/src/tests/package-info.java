/**
 * Package contenant l'ensemble des tests JUnit4
 */
package tests;