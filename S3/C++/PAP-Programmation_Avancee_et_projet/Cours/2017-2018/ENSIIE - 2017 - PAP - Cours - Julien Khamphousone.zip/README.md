Attention, ce pdf de notes de cours de PAP n'est pas complet. Il manque la première partie du cours que j'ai prise à la main avant de décider de taper la fin du cours en LaTeX.
